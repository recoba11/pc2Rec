import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { CyberAttack } from '../models/CyberAttack';

const base_url = environment.base

@Injectable({
  providedIn: 'root',
})
export class Cyberattackservice {
  private url = `${base_url}/api/attacks`

  constructor(private http: HttpClient) { }

  list() {
    return this.http.get<CyberAttack[]>(this.url);
  }
}
