import { Component } from '@angular/core';

@Component({
  selector: 'app-rf-valenzuela-perfil-componente',
  imports: [],
  templateUrl: './rf_valenzuela-perfil-componente.html',
  styleUrl: './rf_valenzuela-perfil-componente.css',
})
export class RfValenzuelaPerfilComponente {
  nombre: string = 'Recoba Funciyu Valenzuela Huaynillo'
  codigo: string = 'u20221d271'
  carrera: string = 'Ingeniería de Sistemas de Información'
  ciclo: string = '7mo ciclo'
  skills: string[] = ['Angular', 'TypeScript', 'Angular Material', 'Spring Boot', 'Java', 'PostgreSQL']
  foto: string = 'perfil.svg'
}
