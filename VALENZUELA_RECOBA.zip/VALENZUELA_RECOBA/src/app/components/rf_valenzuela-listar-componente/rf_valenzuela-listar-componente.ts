import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CyberAttack } from '../../models/CyberAttack';
import { MatTableDataSource } from '@angular/material/table';
import { Cyberattackservice } from '../../services/cyberattackservice';
import { MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';

@Component({
  selector: 'app-rf-valenzuela-listar-componente',
  imports: [MatTableModule, MatPaginatorModule, MatSortModule, DatePipe],
  templateUrl: './rf_valenzuela-listar-componente.html',
  styleUrl: './rf_valenzuela-listar-componente.css',
})
export class RfValenzuelaListarComponente implements OnInit, AfterViewInit {
  dataSource: MatTableDataSource<CyberAttack> = new MatTableDataSource();
  displayedColumns: string[] = ['idCyberAttack', 'attackName', 'attackType', 'attackTime', 'attackDate'];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private cS: Cyberattackservice) { }

  ngOnInit(): void {
    this.cargarAtaques()
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator
    this.dataSource.sort = this.sort
  }

  cargarAtaques() {
    this.cS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data
      }
    })
  }

}
