export class CyberAttack {
    idCyberAttack: number = 0
    attackName: string = ""
    attackDescription: string = ""
    attackType: string = ""
    attackDate: Date = new Date()
    attackTime: string = ""
}
