import { Routes } from '@angular/router';
import { RfValenzuelaListarComponente } from './components/rf_valenzuela-listar-componente/rf_valenzuela-listar-componente';
import { RfValenzuelaPerfilComponente } from './components/rf_valenzuela-perfil-componente/rf_valenzuela-perfil-componente';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'valenzuela/listar',
        pathMatch: 'full'
    },
    {
        path: 'valenzuela/listar',
        component: RfValenzuelaListarComponente
    },
    {
        path: 'valenzuela/certificado',
        component: RfValenzuelaPerfilComponente
    }
];
