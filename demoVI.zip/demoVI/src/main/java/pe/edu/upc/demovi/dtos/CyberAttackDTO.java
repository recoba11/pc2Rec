package pe.edu.upc.demovi.dtos;

import java.time.LocalDate;
import java.time.LocalTime;

public class CyberAttackDTO {
    private Long idCyberAttack;
    private String attackName;
    private String attackDescription;
    private String attackType;
    private LocalDate attackDate;
    private LocalTime attackTime;

    public Long getIdCyberAttack() {
        return idCyberAttack;
    }

    public void setIdCyberAttack(Long idCyberAttack) {
        this.idCyberAttack = idCyberAttack;
    }

    public String getAttackName() {
        return attackName;
    }

    public void setAttackName(String attackName) {
        this.attackName = attackName;
    }

    public String getAttackDescription() {
        return attackDescription;
    }

    public void setAttackDescription(String attackDescription) {
        this.attackDescription = attackDescription;
    }

    public String getAttackType() {
        return attackType;
    }

    public void setAttackType(String attackType) {
        this.attackType = attackType;
    }

    public LocalDate getAttackDate() {
        return attackDate;
    }

    public void setAttackDate(LocalDate attackDate) {
        this.attackDate = attackDate;
    }

    public LocalTime getAttackTime() {
        return attackTime;
    }

    public void setAttackTime(LocalTime attackTime) {
        this.attackTime = attackTime;
    }
}
