package pe.edu.upc.demovi.servicesimplements;

import org.springframework.stereotype.Service;
import pe.edu.upc.demovi.entities.CyberAttack;
import pe.edu.upc.demovi.repositories.ICyberAttackRepository;
import pe.edu.upc.demovi.servicesinterfaces.ICyberAttackService;

import java.util.List;
import java.util.Optional;
@Service
public class CyberAttackServiceImplement implements ICyberAttackService {

    private final ICyberAttackRepository cR;

    public CyberAttackServiceImplement(ICyberAttackRepository cR) {
        this.cR = cR;
    }

    @Override
    public void insert(CyberAttack c) {
        cR.save(c);
    }

    @Override
    public List<CyberAttack> list() {
        return cR.findAll();
    }

    @Override
    public Optional<CyberAttack> listId(Long id) {
        return cR.findById(id);
    }

    @Override
    public void delete(Long id) {
        cR.deleteById(id);
    }

    @Override
    public void update(CyberAttack c) {
        cR.save(c);
    }
}
