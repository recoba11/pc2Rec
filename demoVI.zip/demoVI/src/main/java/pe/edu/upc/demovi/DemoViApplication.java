package pe.edu.upc.demovi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoViApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoViApplication.class, args);
    }

}
