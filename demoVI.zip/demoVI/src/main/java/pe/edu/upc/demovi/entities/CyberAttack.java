package pe.edu.upc.demovi.entities;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalTime;
@Entity
@Table(name = "cyberattacks")
public class CyberAttack {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idCyberAttack;
    @Column(name = "attackName",nullable = false, length = 45)
    private String attackName;
    @Column(name = "attackDescription",nullable = false, length = 200)
    private String attackDescription;
    @Column(name = "attackType",nullable = false, length = 200)
    private String attackType;
    @Column(name = "attackDate",nullable = false)
    private LocalDate attackDate;
    @Column(name = "attackTime",nullable = false)
    private LocalTime attackTime;

    public CyberAttack() {
    }

    public CyberAttack(Long idCyberAttack, String attackName, String attackDescription, String attackType, LocalDate attackDate, LocalTime attackTime) {
        this.idCyberAttack = idCyberAttack;
        this.attackName = attackName;
        this.attackDescription = attackDescription;
        this.attackType = attackType;
        this.attackDate = attackDate;
        this.attackTime = attackTime;
    }

    public Long getIdCyberAttack() {
        return idCyberAttack;
    }

    public void setIdCyberAttack(Long idCyberAttack) {
        this.idCyberAttack = idCyberAttack;
    }

    public String getAttackName() {
        return attackName;
    }

    public void setAttackName(String attackName) {
        this.attackName = attackName;
    }

    public String getAttackDescription() {
        return attackDescription;
    }

    public void setAttackDescription(String attackDescription) {
        this.attackDescription = attackDescription;
    }

    public String getAttackType() {
        return attackType;
    }

    public void setAttackType(String attackType) {
        this.attackType = attackType;
    }

    public LocalDate getAttackDate() {
        return attackDate;
    }

    public void setAttackDate(LocalDate attackDate) {
        this.attackDate = attackDate;
    }

    public LocalTime getAttackTime() {
        return attackTime;
    }

    public void setAttackTime(LocalTime attackTime) {
        this.attackTime = attackTime;
    }
}
