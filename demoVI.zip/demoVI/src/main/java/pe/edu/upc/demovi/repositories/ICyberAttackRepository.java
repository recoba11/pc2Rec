package pe.edu.upc.demovi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upc.demovi.entities.CyberAttack;
@Repository
public interface ICyberAttackRepository extends JpaRepository<CyberAttack,Long> {
}
