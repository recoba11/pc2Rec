package pe.edu.upc.demovi.servicesinterfaces;

import pe.edu.upc.demovi.entities.CyberAttack;

import java.util.List;
import java.util.Optional;

public interface ICyberAttackService {
    public void insert(CyberAttack c);
    public List<CyberAttack> list();
    public Optional<CyberAttack> listId(Long id);
    public void delete(Long id);
    public void update(CyberAttack c);

}
