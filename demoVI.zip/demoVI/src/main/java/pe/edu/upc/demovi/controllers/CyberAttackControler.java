package pe.edu.upc.demovi.controllers;

import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import pe.edu.upc.demovi.dtos.CyberAttackDTO;
import pe.edu.upc.demovi.entities.CyberAttack;
import pe.edu.upc.demovi.exceptions.ResourceNotFoundException;
import pe.edu.upc.demovi.servicesinterfaces.ICyberAttackService;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/attacks")
public class CyberAttackControler {
    private final ICyberAttackService cS;
    private final ModelMapper modelMapper;

    public CyberAttackControler(ICyberAttackService cS, ModelMapper modelMapper) {
        this.cS = cS;
        this.modelMapper = modelMapper;
    }


    @GetMapping
    public ResponseEntity<List<CyberAttackDTO>> listar() {

        List<CyberAttackDTO> lista = cS.list()
                .stream()
                .map(crop -> modelMapper.map(crop, CyberAttackDTO.class))
                .toList();

        return ResponseEntity.ok(lista);
    }
    @PostMapping
    public ResponseEntity<CyberAttackDTO> registrar(
            @Valid @RequestBody CyberAttackDTO dto) {

        CyberAttack c = modelMapper.map(dto, CyberAttack.class);
        c.setIdCyberAttack(null);
        cS.insert(c);

        CyberAttackDTO responseDTO =
                modelMapper.map(c, CyberAttackDTO.class);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(c.getIdCyberAttack())
                .toUri();

        return ResponseEntity
                .created(location)
                .body(responseDTO);
    }
    @GetMapping("/{id}")
    public ResponseEntity<CyberAttackDTO> buscarPorId(
            @PathVariable Long id) {

        CyberAttack ci = cS.listId(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "No existe un ciber-ataque con el id: " + id
                        )
                );

        CyberAttackDTO dto = modelMapper.map(ci, CyberAttackDTO.class);

        return ResponseEntity.ok(dto);
    }
    @PutMapping
    public ResponseEntity<CyberAttackDTO> actualizar(
            @Valid @RequestBody CyberAttackDTO dto) {
        CyberAttack existente = cS.listId(dto.getIdCyberAttack())
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "No existe un ciber-ataque con el id: " + dto.getIdCyberAttack()
                        )
                );
        CyberAttack c = modelMapper.map(dto, CyberAttack.class);
        c.setIdCyberAttack(existente.getIdCyberAttack());
        cS.update(c);
        CyberAttackDTO responseDTO =
                modelMapper.map(c, CyberAttackDTO.class);
        return ResponseEntity.ok(responseDTO);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        CyberAttack c = cS.listId(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "No existe un ciber-ataque con el id: " + id
                        )
                );
        cS.delete(c.getIdCyberAttack());
        return ResponseEntity.noContent().build();
    }

}
