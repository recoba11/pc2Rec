export class Machine {
    idMachine: number = 0
    nameMachine: string = ""
    statusMachine: boolean = false
    buyDateMachine: Date = new Date()
    typeMachine: string = ""
    quantityWarrantyMachine: number = 0
}