import { Component, OnInit } from '@angular/core';
import { Machine } from '../../../models/Machine';
import { MatTableDataSource } from '@angular/material/table';
import { Machineservice } from '../../../services/machineservice';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-machine-list',
  imports: [MatTableModule, MatButtonModule, MatIconModule],
  templateUrl: './machine-list.html',
  styleUrl: './machine-list.css',
})
export class MachineList implements OnInit {
  dataSource: MatTableDataSource<Machine> = new MatTableDataSource();
  displayedColumns: string[] = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7'];

  constructor(private mS: Machineservice) { }

  ngOnInit(): void {
    this.cargarMaquinas()
  }

  cargarMaquinas() {
    this.mS.list().subscribe({
      next: (data) => {
        this.dataSource.data = data
      }
    })
  }
  eliminar(id: number) {
    this.mS.delete(id).subscribe(data => {
      this.mS.list().subscribe(data => {
        this.dataSource.data = data
      })
    })
  }

}
