import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouterOutlet } from '@angular/router';
import { MachineList } from './machine-list/machine-list';

@Component({
  selector: 'app-machinecomponent',
  imports: [RouterOutlet, MachineList],
  templateUrl: './machinecomponent.html',
  styleUrl: './machinecomponent.css',
})
export class Machinecomponent {
  constructor(public route: ActivatedRoute) { }
}
