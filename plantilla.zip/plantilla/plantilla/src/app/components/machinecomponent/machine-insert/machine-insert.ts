import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Machine } from '../../../models/Machine';
import { Machineservice } from '../../../services/machineservice';
import { Router } from '@angular/router';
import { MatInputModule } from '@angular/material/input';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-machine-insert',
  imports: [
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatSelectModule,
    MatButtonModule,
    ReactiveFormsModule

  ],
  templateUrl: './machine-insert.html',
  providers: [provideNativeDateAdapter()],
  styleUrl: './machine-insert.css',
})
export class MachineInsert implements OnInit {

  form: FormGroup = new FormGroup({})
  mac: Machine = new Machine()
  tipos: { value: string; viewValue: string }[] = [
    { value: 'Industrial', viewValue: 'Industrial' },
    { value: 'Profesional', viewValue: 'Profesional' }
  ]
  constructor(private mS: Machineservice,
    private router: Router,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {

    this.form = this.formBuilder.group({
      name: ['', Validators.required],
      state: [false, Validators.required],
      dateB: ['', Validators.required],
      type: ['', Validators.required],
      warranty: ['', Validators.required]
    })
  }

  aceptar() {
    if (this.form.valid) {

      this.mac.nameMachine = this.form.value.name
      this.mac.statusMachine = this.form.value.state
      this.mac.buyDateMachine = this.form.value.dateB
      this.mac.typeMachine = this.form.value.type
      this.mac.quantityWarrantyMachine = this.form.value.warranty
      this.mS.insert(this.mac).subscribe({
        next: () => {
          this.router.navigate(['/machines/listas'])
        }
      })
    }
  }


}
