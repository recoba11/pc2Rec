import { Routes } from '@angular/router';
import { Homecomponent } from './components/homecomponent/homecomponent';
import { Machinecomponent } from './components/machinecomponent/machinecomponent';
import { MachineList } from './components/machinecomponent/machine-list/machine-list';
import { MachineInsert } from './components/machinecomponent/machine-insert/machine-insert'

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'homes',
        pathMatch: 'full'
    },
    {
        path: 'homes',
        component: Homecomponent
    },
    {
        path: 'machines',
        component: Machinecomponent,
        children: [
            {
                path: 'listas',
                component: MachineList
            },
            {
                path: 'nuevo',
                component: MachineInsert
            }

        ]
    }
];
