import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.development';
import { Machine } from '../models/Machine';

const base_url = environment.base

@Injectable({
  providedIn: 'root',
})
export class Machineservice {
  private url = `${base_url}/api-maquinas`

  constructor(private http: HttpClient) { }

  list() {
    return this.http.get<Machine[]>(`${this.url}/lista`);
  }
  insert(m: Machine) {
    return this.http.post(`${this.url}/nuevo`, m)
  }
  delete(id: number) {
    return this.http.delete(`${this.url}/${id}`, { responseType: 'text' })
  }
}
